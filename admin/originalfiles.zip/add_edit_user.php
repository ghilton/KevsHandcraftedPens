<?php
include "../init.php";// include init
include "../config_db.php";// database connection details stored here
include "include/protecteed.php";// page protect function here

$tabl = 'users';
$item = 'User';
$id = mysql_real_escape_string($_GET['id']);
$relation = mysql_real_escape_string($_GET['relation']);

if($_GET['do'] == 'edit'){
	$sql = "SELECT * from $tabl where id='$id'";
	$exec = mysql_query($sql) or die(mysql_error());
	$fetch = mysql_fetch_assoc($exec);
	$dvar['first_name'] = $fetch['first_name'];
	$dvar['last_name'] = $fetch['last_name'];
	$dvar['country'] = $fetch['country'];
	$dvar['email'] = $fetch['email'];
	$dvar['user_type'] = $fetch['user_type'];
	$dvar['password'] = $fetch['password'];
	$dvar['status'] = $fetch['status'];

}

if($_POST['submitbut'] == 'Submit'){
	$dvar['first_name'] = $_POST['first_name'];
	$dvar['last_name'] = $_POST['last_name'];
	$dvar['country'] = $_POST['country'];
	$dvar['email'] = $_POST['email'];
	$dvar['user_type'] = $_POST['user_type'];
	$dvar['password'] = $_POST['password'];
	$dvar['status'] = $_POST['status'];

	
    if($dvar['first_name'] == ''){$flag[26] = 'r';}
	else if($dvar['last_name'] == ''){$flag[27] = 'r';}
	else if($dvar['country'] == ''){$flag[31] = 'r';}
	else if($dvar['email'] == ''){$flag[4] = 'r';}
	else if($dvar['password'] == ''){$flag[11] = 'r';}
	else if($dvar['user_type'] == ''){$flag[11] = 'r';}
	
	if(!empty($flag)){
		$flag_r = 'r';
	}
	else{
		if($_GET['do'] == 'edit'){
			$add_dvar = array('time' => time());
//			$remove_dvar = array('status');
//			$change_dvar = array('status' => '0');
			
			$sql = "UPDATE $tabl SET ".update_query($dvar, $add_dvar, $remove_dvar, $change_dvar)." where id='$id'";

			$fg = 'ed';
		}
		else{
			$add_dvar = array('time' => time());
//			$remove_dvar = array('status');
//			$change_dvar = array('status' => '1');

			list($insert_q[0], $insert_q[1]) = insert_query($dvar, $add_dvar, $remove_dvar, $change_dvar);
			
			$sql = "INSERT into $tabl(sort, $insert_q[0]) SELECT max(sort)+1, $insert_q[1] from $tabl";
			$fg = 'ad';
		}
		if(mysql_query($sql)){
			$flag = 'g';
		}
		else{
			die(mysql_error());
		}
	}
}

if($_GET['do'] == 'edit' && ($flag == 'g')){
	$sql = "SELECT * from $tabl where id='$id'";
	$exec = mysql_query($sql) or die(mysql_error());
	$fetch = mysql_fetch_assoc($exec);
	$dvar['first_name'] = $fetch['first_name'];
	$dvar['last_name'] = $fetch['last_name'];
	$dvar['country'] = $fetch['country'];
	$dvar['email'] = $fetch['email'];
	$dvar['user_type'] = $fetch['user_type'];
	$dvar['password'] = $fetch['password'];
	$dvar['status'] = $fetch['status'];
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add/Edit <?php echo $item; ?></title>
<?php include("include/head.php"); ?>

<script type="text/javascript">
jQuery(document).ready(function () {
	$('input#start_date').simpleDatepicker({ startdate: 2012, enddate: 2099 });
	$('input#end_date').simpleDatepicker({ startdate: 2012, enddate: 2099 });
});
</script>
<?php
if($flag == 'g'){
?>
<meta http-equiv="refresh" content="3; URL=manage_users.php">
<?php } ?>
</head>

<body>
<div align="center">
  <div class="container">
	<?php
    $pg_active['user'] = 'active';
    require_once('include/header.php'); 
    ?>
    <div class="content">
      <div style="margin-top:10px">
    <div class="error" id="error" style="display:none"></div>
    <?php
        echo print_messages($flag, $error_message, $success_message);
		if($flag == 'g'){
		?>
		<div class="success">Success: <?php echo $item.'&nbsp;'; if($_GET['do'] == 'edit'){echo $success_message[0];} else{echo $success_message[1];} ?>
        </div>
        <?php
			}
		?>
      </div>
      <div class="form5">
        <form id="customers" name="add" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?do=<?php echo $_GET['do'].'&id='.$_GET['id']; ?>" enctype="multipart/form-data">
          <input name="do" value="<?php echo $do; ?>" type="hidden" />
          <input name="type" value="<?php echo $_GET['type']; ?>" type="hidden" />
          <input name="relation" value="<?php echo $_GET['relation']; ?>" type="hidden" />
			<?php
			if($do == 'edit'){
				echo '<input name="id" value="'.$id.'" type="hidden" />';
			}
			?>
            <table width="950" border="0" cellpadding="5">
             
              <tr>
                <td width="125" align="right" class="label_form">First Name<span class="star">*</span> : </td>
                <td width="812"><input id="first_name" name="first_name" class="input_text" type="text" value="<?php echo $dvar['first_name']; ?>" /></td>
              </tr>
              <tr>
                <td width="125" align="right" class="label_form">Last Name<span class="star">*</span> : </td>
                <td width="812"><input id="last_name" name="last_name" class="input_text" type="text" value="<?php echo $dvar['last_name']; ?>" /></td>
              </tr>
             <tr>
                <td width="125" align="right" class="label_form">Email ID<span class="star">*</span> : </td>
                <td width="812"><input id="email" name="email" class="input_text" type="text" value="<?php echo $dvar['email']; ?>" /></td>
              </tr>
              <tr>
                <td width="125" align="right" class="label_form">Country<span class="star">*</span> : </td>
                <td width="812"><input id="country" name="country" class="input_text" type="text" value="<?php echo $dvar['country']; ?>" /></td>
              </tr>
              <tr>
                <td width="125" align="right" class="label_form">User Type<span class="star">*</span> : </td>
                <td width="812"><input id="username" name="user_type" class="input_text" type="text" value="<?php echo $dvar['user_type']; ?>" /></td>
              </tr>
              <tr>
                <td width="125" align="right" class="label_form">Password<span class="star">*</span> : </td>
                <td width="812"><input id="password" name="password" class="input_text" type="text" value="<?php echo $dvar['password']; ?>" /></td>
              </tr>
              <tr>
                <td align="right" class="label_form"><div class="view1">User Status :</div></td>
                <td><div class="view2">
                    <input name="status"  type="radio" value="1" <?php if($dvar['status'] == '1'){echo 'checked="checked"';} ?> />&nbsp;<span style="color:#009900">Active</span>
                    <input name="status"  type="radio" value="0" <?php if($dvar['status'] == '0'){echo 'checked="checked"';} ?>  />&nbsp;<span style="color:#ff0000">Inactive</span>
                    <input name="status"  type="radio" value="2"  <?php if($dvar['status'] == '2'){echo 'checked="checked"';} ?> />&nbsp;<span style="color:#990000">Banned</span>
                 </div></td>
        	 </tr>
             
              <tr>
                <td>&nbsp;</td>
                <td>
                    <div class="btn">
                        <input class="button" name="submitbut" value="Submit" type="submit" />
                        <a class="a_button" href="manage_users<?php // echo strtolower($item); ?>.php">Close</a>
                    </div>
                </td>
              </tr>
            </table>
        </form>
      </div>
      <?php
	  	include "include/footerlogo.php";
	  ?>
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>
