<?php
include "../init.php";                       // include init for root url, sitename etc
include "../config_db.php";                  // database connection details stored here
include "include/protecteed.php";            // page protect function here
$time = time();							     // for current time 
$tabl = 'social_links';						     // for database table name that used on this page
$item = 'Social Links';
$page_parent = 'edit_social_links.php';           // for redirection 
$query_string = array("search" => $_GET['search'],"type" =>"1", "page" => $_GET['page'], "rel_id" => $_GET['rel_id'], "do" => $_GET['do'], "id" => $_GET['id']);
foreach($query_string as $k=>$v){
	$q_string .= "&$k=$v";
}

$id = mysql_real_escape_string($_GET['id']);
$relation = mysql_real_escape_string($_GET['relation']);

if($_GET['do'] == 'edit'){									// for fetch data on edit page
	$sql = "SELECT * from $tabl where id='$id'";
	$exec = mysql_query($sql) or die(mysql_error());
	$fetch = mysql_fetch_assoc($exec);
	$dvar['facebook'] = $fetch['facebook'];
	$dvar['g_plus'] = $fetch['g_plus'];
	$dvar['twitter'] = $fetch['twitter'];
	
}

if($_POST['submitbut'] == 'Save'){								// for save data in database
	$dvar['facebook'] = $_POST['facebook'];
	$dvar['g_plus'] = $_POST['g_plus'];
	$dvar['twitter'] = $_POST['twitter'];
	
	
	if(!empty($flag)){
		$flag_r = 'r';
	}
	else{
		if($_GET['do'] == 'edit'){
			$sql_s = "select * from $tabl where id='".$id."'"; //for 
			$exec_s = mysql_query($sql_s);
			$fetch_s = mysql_fetch_assoc($exec_s);

			 // for upadtion in database
			$add_dvar = array('time' => time());
//			$remove_dvar = array('image_delete');
//			$change_dvar = array('status' => '0');
			$sql = "UPDATE $tabl SET ".update_query($dvar, $add_dvar, $remove_dvar, $change_dvar)." where id='".$id."'";

			$fg = 'ed';
		}
		else{
			$uniq = random_generator(10);
			 // for insert data in database
			$add_dvar = array('uniq' => $uniq, 'time' => time(), 'status' => '1');
			$remove_dvar = array('image_delete');
//			$change_dvar = array('status' => '1');

			list($insert_q[0], $insert_q[1]) = insert_query($dvar, $add_dvar, $remove_dvar, $change_dvar);
		    $sql = "INSERT into $tabl(sort, $insert_q[0]) SELECT max(sort)+1, $insert_q[1] from $tabl";
			$fg = 'ad';
		}
		if(mysql_query($sql)){
			$flag[$fg] = $item;
		}
		else{
			$flag['q'] = 'r';
		}
	}
}

//for show data after submit form

if($_GET['do'] == 'edit' && ($flag == 'g')){
	$sql = "SELECT * from $tabl where id='$id'";
	$exec = mysql_query($sql) or die(mysql_error());
	$fetch = mysql_fetch_assoc($exec);
	$dvar['facebook'] = $fetch['facebook'];
	$dvar['g_plus'] = $fetch['g_plus'];
	$dvar['twitter'] = $fetch['twitter'];
}


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Add/Edit <?php echo $item; ?></title>
<?php include("include/head.php"); ?>
<!-- <script>
  var myCalendar;
  function doOnLoad() {
   myCalendar = new dhtmlXCalendarObject(["date_of_birth"]);
  }
 </script>-->
<?php
// after addition/updation redirection
if($flag[$fg] <> ''){
?>
<meta http-equiv="refresh" content="3; URL=<?php echo $page_parent."?1=1".$q_string; ?>">
<?php } ?>
</head>

<body>
<div align="center">
  <div class="container">
    <?php  $pg_active['con'] = 'active';  require_once('include/header.php'); ?>
    <div class="content">
      <div style="margin-top:10px"> <?php echo print_messages($flag, $error_message, $success_message); ?> </div>
      <div class="form5"> 
        <!--For Form fields-->
        <form id="add" name="add" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>?do=<?php echo $_GET['do'].'&uniq='.$uniq.'&id='.$_GET['id']; ?>" enctype="multipart/form-data">
          <table width="100%" border="0" cellpadding="5">
            <tr>
              <td align="right" class="label_form"></td>
              <td class="label_form"><u><b><?php echo $item; ?></b></u></td>
            </tr>
            <tr>
              <td align="right" class="label_form" valign="top">Facebook: </td>
              <td class="txt1input"><textarea style="margin-top:0px; height:70px; width:500px;" name="facebook"><?php echo $dvar['facebook'];?></textarea></td>
            </tr>
            <tr>
              <td align="right" class="label_form" valign="top">Twitter: </td>
              <td class="txt1input"><textarea style="margin-top:0px; height:70px; width:500px;" name="twitter"><?php echo $dvar['twitter'];?></textarea></td>
            </tr>
            <tr>
              <td align="right" class="label_form" valign="top">Google Plus: </td>
              <td class="txt1input"><textarea style="margin-top:0px; height:70px; width:500px;" name="g_plus"><?php echo $dvar['g_plus'];?></textarea></td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td><div class="btn">
                  <input class="button" name="submitbut" value="Save" type="submit" />
                  <a class="a_button" href="<?php echo $page_parent."?1=1".$q_string; ?>">Cancel</a> </div></td>
            </tr>
          </table>
        </form>
      </div>
      <?php
	  	// include "include/footerlogo.php";
	  ?>
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>
